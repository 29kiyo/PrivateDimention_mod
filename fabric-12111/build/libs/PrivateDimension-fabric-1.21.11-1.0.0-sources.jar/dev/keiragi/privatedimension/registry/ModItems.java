package dev.keiragi.privatedimension.registry;

import dev.keiragi.privatedimension.item.DimensionBottleItem;
import net.minecraft.class_1792;

public class ModItems {
    public static DimensionBottleItem DIMENSION_BOTTLE;

    public static DimensionBottleItem createDimensionBottle() {
        DIMENSION_BOTTLE = new DimensionBottleItem(new class_1792.class_1793().method_7889(1));
        return DIMENSION_BOTTLE;
    }
}

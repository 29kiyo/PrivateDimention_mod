package dev.keiragi.privatedimension.dimension;

import dev.keiragi.privatedimension.PrivateDimensionMod;
import dev.keiragi.privatedimension.util.IdUtils;
import dev.keiragi.privatedimension.util.NbtStructurePlacer;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import net.minecraft.class_5218;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Arrays;

public class DimensionManager {

    public static final Object DIMENSION_ID =
        IdUtils.createId(PrivateDimensionMod.MOD_ID, "private_dimension");

    @SuppressWarnings("rawtypes")
    public static final Object DIMENSION_KEY =
        IdUtils.createResourceKey(class_7924.field_41223, DIMENSION_ID);

    private final PrivateDimensionMod mod;
    private MinecraftServer server;

    public DimensionManager(PrivateDimensionMod mod) { this.mod = mod; }

    public void onServerStart(MinecraftServer server) {
        this.server = server;
        class_3218 dim = getPrivateDimension();
        if (dim != null) {
            PrivateDimensionMod.LOGGER.info("プライベート次元ワールドを確認しました: {}", DIMENSION_ID);
        } else {
            PrivateDimensionMod.LOGGER.warn("プライベート次元が見つかりません。データパック確認が必要です。");
        }
    }

    public class_3218 getPrivateDimension() {
        return server == null ? null : server.method_3847((class_5321<class_1937>) DIMENSION_KEY);
    }

    public boolean isPrivateDimension(class_3218 level) {
        return level != null && level.method_27983().equals(DIMENSION_KEY);
    }

    public void placeStructure(class_3218 level, class_2338 origin) {
        try {
            ensureNbtExtracted(level);
            Path structDir = level.method_8503().method_27050(class_5218.field_24188)
                .resolve("generated")
                .resolve(PrivateDimensionMod.MOD_ID)
                .resolve("structures");
            Path nbtPath = structDir.resolve("plot48x48.nbt");
            if (!Files.exists(nbtPath)) {
                PrivateDimensionMod.LOGGER.error("NBTファイルが見つかりません: {}", nbtPath);
                return;
            }
            boolean result = NbtStructurePlacer.place(level, origin, nbtPath);
            PrivateDimensionMod.LOGGER.info("構造物配置完了: {} placed={}", origin, result);
        } catch (Exception e) {
            PrivateDimensionMod.LOGGER.error("構造物配置失敗: {}", e.getMessage(), e);
        }
    }

    private void ensureNbtExtracted(class_3218 level) throws IOException {
        Path structDir = level.method_8503().method_27050(class_5218.field_24188)
            .resolve("generated")
            .resolve(PrivateDimensionMod.MOD_ID)
            .resolve("structures");
        Files.createDirectories(structDir);
        Path dest = structDir.resolve("plot48x48.nbt");

        try (InputStream in = DimensionManager.class.getResourceAsStream("/plot48x48.nbt")) {
            if (in == null) { PrivateDimensionMod.LOGGER.error("plot48x48.nbt リソースなし！"); return; }
            byte[] bytes = in.readAllBytes();
            if (!Files.exists(dest) || !md5Matches(dest, bytes)) {
                Files.write(dest, bytes);
                PrivateDimensionMod.LOGGER.info("plot48x48.nbt を展開しました。");
            }
        }
    }

    private boolean md5Matches(Path file, byte[] ref) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            return Arrays.equals(md.digest(Files.readAllBytes(file)), md.digest(ref));
        } catch (Exception e) { return false; }
    }
}

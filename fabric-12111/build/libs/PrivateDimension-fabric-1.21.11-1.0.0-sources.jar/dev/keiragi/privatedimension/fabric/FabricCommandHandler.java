package dev.keiragi.privatedimension.fabric;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.keiragi.privatedimension.CommonEventHandler;
import dev.keiragi.privatedimension.PrivateDimensionMod;
import dev.keiragi.privatedimension.item.DimensionBottleItem;
import dev.keiragi.privatedimension.manager.PlayerDataManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.UUID;

public class FabricCommandHandler {

    static void register(PrivateDimensionMod mod, CommonEventHandler eventHandler) {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("pd")
                .then(class_2170.method_9247("give")
                    .requires(class_2170.method_71774(class_2170.field_31839))
                    .executes(ctx -> giveSelf(ctx, mod))
                    .then(class_2170.method_9244("player", StringArgumentType.word())
                        .executes(ctx -> givePlayer(ctx, mod))))
                .then(class_2170.method_9247("reload")
                    .requires(class_2170.method_71774(class_2170.field_31839))
                    .executes(ctx -> reload(ctx, mod)))
                .then(class_2170.method_9247("info")
                    .executes(ctx -> info(ctx, mod))));
            dispatcher.register(class_2170.method_9247("privatedim")
                .redirect(dispatcher.getRoot().getChild("pd")));
        });
    }

    private static int giveSelf(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        try {
            class_3222 player = ctx.getSource().method_9207();
            player.method_31548().method_7394(DimensionBottleItem.createItem());
            ctx.getSource().method_9226(() -> class_2561.method_43470("§a[PD] アイテムを付与しました。"), false);
            return 1;
        } catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("プレイヤーとして実行してください。"));
            return 0;
        }
    }

    private static int givePlayer(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        String name = StringArgumentType.getString(ctx, "player");
        class_3222 target = ctx.getSource().method_9211().method_3760().method_14566(name);
        if (target == null) {
            ctx.getSource().method_9213(class_2561.method_43470("§cプレイヤーが見つかりません: " + name));
            return 0;
        }
        target.method_31548().method_7394(DimensionBottleItem.createItem());
        ctx.getSource().method_9226(() -> class_2561.method_43470("§a[PD] " + target.method_5477().getString() + " に付与しました。"), false);
        return 1;
    }

    private static int reload(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        mod.getConfig().load();
        ctx.getSource().method_9226(() -> class_2561.method_43470("§a[PD] 設定をリロードしました。"), false);
        return 1;
    }

    private static int info(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        try {
            class_3222 player = ctx.getSource().method_9207();
            UUID uid = player.method_5667();
            PlayerDataManager pdm = mod.getPlayerDataManager();
            if (pdm.hasPlot(uid)) {
                int id = pdm.getPlotId(uid);
                double[] pos = pdm.getPlotPos(uid);
                player.method_64398(class_2561.method_43470("§b[PD] プロットID: §f" + id));
                if (pos != null)
                    player.method_64398(class_2561.method_43470(
                        String.format("§b次元内最終座標: §f%.1f, %.1f, %.1f", pos[0], pos[1], pos[2])));
            } else {
                player.method_64398(class_2561.method_43470("§b[PD] まだプロットを持っていません。"));
            }
            return 1;
        } catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("プレイヤーとして実行してください。"));
            return 0;
        }
    }
}

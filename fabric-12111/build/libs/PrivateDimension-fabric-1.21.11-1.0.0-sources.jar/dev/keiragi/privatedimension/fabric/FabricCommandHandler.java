package dev.keiragi.privatedimension.fabric;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import dev.keiragi.privatedimension.CommonEventHandler;
import dev.keiragi.privatedimension.PrivateDimensionMod;
import dev.keiragi.privatedimension.manager.PlayerDataManager;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_12099;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import java.util.UUID;

public class FabricCommandHandler {

    static void register(PrivateDimensionMod mod, CommonEventHandler eventHandler) {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(
                class_2170.method_9247("pd")
                    .then(class_2170.method_9247("give")
                        .requires(src -> src.method_75037().hasPermission(class_12099.field_63210))
                        .executes(ctx -> giveSelf(ctx, mod))
                        .then(class_2170.method_9244("player", StringArgumentType.word())
                            .executes(ctx -> givePlayer(ctx, mod))))
                    .then(class_2170.method_9247("reload")
                        .requires(src -> src.method_75037().hasPermission(class_12099.field_63210))
                        .executes(ctx -> reload(ctx, mod)))
                    .then(class_2170.method_9247("info")
                        .executes(ctx -> info(ctx, mod)))
                    .then(class_2170.method_9247("tp")
                        .executes(ctx -> tp(ctx, mod, eventHandler)))
            );
            dispatcher.register(
                class_2170.method_9247("privatedim")
                    .redirect(dispatcher.getRoot().getChild("pd"))
            );
        });
    }

    private static int tp(CommandContext<class_2168> ctx, PrivateDimensionMod mod, CommonEventHandler eventHandler) {
        class_3222 player;
        try { player = ctx.getSource().method_9207(); }
        catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("プレイヤーとして実行してください。"));
            return 0;
        }
        eventHandler.onItemUse(player, player.method_6047());
        return 1;
    }

    private static int giveSelf(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        class_3222 player;
        try { player = ctx.getSource().method_9207(); }
        catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("プレイヤーとして実行してください。"));
            return 0;
        }
        if (dev.keiragi.privatedimension.registry.ModItems.DIMENSION_BOTTLE != null)
            player.method_31548().method_7394(new net.minecraft.class_1799(dev.keiragi.privatedimension.registry.ModItems.DIMENSION_BOTTLE));
        ctx.getSource().method_9226(() ->
            class_2561.method_43470("§a[PrivateDimension] アイテムを付与しました。"), false);
        return 1;
    }

    private static int givePlayer(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        String name = StringArgumentType.getString(ctx, "player");
        class_3222 target = ctx.getSource().method_9211().method_3760().method_14566(name);
        if (target == null) {
            ctx.getSource().method_9213(class_2561.method_43470("§cプレイヤーが見つかりません: " + name));
            return 0;
        }
        if (dev.keiragi.privatedimension.registry.ModItems.DIMENSION_BOTTLE != null)
            target.method_31548().method_7394(new net.minecraft.class_1799(dev.keiragi.privatedimension.registry.ModItems.DIMENSION_BOTTLE));
        ctx.getSource().method_9226(() ->
            class_2561.method_43470("§a[PrivateDimension] " + target.method_5477().getString() + " にアイテムを付与しました。"), false);
        return 1;
    }

    private static int reload(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        mod.getConfig().load();
        ctx.getSource().method_9226(() ->
            class_2561.method_43470("§a[PrivateDimension] 設定をリロードしました。"), false);
        return 1;
    }

    private static int info(CommandContext<class_2168> ctx, PrivateDimensionMod mod) {
        class_3222 player;
        try { player = ctx.getSource().method_9207(); }
        catch (Exception e) {
            ctx.getSource().method_9213(class_2561.method_43470("プレイヤーとして実行してください。"));
            return 0;
        }
        PlayerDataManager pdm = mod.getPlayerDataManager();
        UUID uid = player.method_5667();
        if (pdm.hasPlot(uid)) {
            player.method_64398(class_2561.method_43470("§b[PrivateDimension] プロットID: §f" + pdm.getPlotId(uid)));
            double[] pos = pdm.getPlotPos(uid);
            if (pos != null)
                player.method_64398(class_2561.method_43470(
                    String.format("§b次元内最終座標: §f%.1f, %.1f, %.1f", pos[0], pos[1], pos[2])));
        } else {
            player.method_64398(class_2561.method_43470("§b[PrivateDimension] まだプロットを持っていません。"));
        }
        return 1;
    }
}

package dev.keiragi.privatedimension.fabric;

import dev.keiragi.privatedimension.CommonEventHandler;
import dev.keiragi.privatedimension.PrivateDimensionMod;
import dev.keiragi.privatedimension.item.DimensionBottleItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import java.util.*;

public class PrivateDimensionFabric implements ModInitializer {
    private PrivateDimensionMod mod;
    private CommonEventHandler eventHandler;
    private final Map<UUID, class_243> lastPos = new HashMap<>();

    @Override
    public void onInitialize() {
        mod = new PrivateDimensionMod();
        mod.getConfig().setConfigPath(
            FabricLoader.getInstance().getConfigDir()
                .resolve(PrivateDimensionMod.MOD_ID)
                .resolve("config.json"));
        mod.init();
        eventHandler = new CommonEventHandler(mod);
        registerEvents();
        FabricCommandHandler.register(mod, eventHandler);
        PrivateDimensionMod.LOGGER.info("PrivateDimension (Fabric) 初期化完了");
    }

    private void registerEvents() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            mod.getDimensionManager().onServerStart(server);
            mod.getPlayerDataManager().setDataPath(
                server.method_27050(class_5218.field_24188)
                    .resolve("privatedimension_playerdata.json"));
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server ->
            mod.getPlayerDataManager().saveAll());

        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (world.method_8608() || !(player instanceof class_3222 sp))
                return net.minecraft.class_1269.field_5811;
            class_1799 stack = player.method_5998(hand);
            if (DimensionBottleItem.isDimensionBottle(stack)) {
                eventHandler.onItemUse(sp, stack);
                return net.minecraft.class_1269.field_5812;
            }
            return net.minecraft.class_1269.field_5811;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                UUID uid = player.method_5667();
                class_243 current = player.method_73189();
                if (!current.equals(lastPos.get(uid))) {
                    eventHandler.onPlayerMove(player, current);
                    lastPos.put(uid, current);
                }
            }
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof class_3222 sp) eventHandler.onPlayerDeath(sp);
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            CommonEventHandler.RespawnInfo info = eventHandler.onPlayerRespawn(newPlayer);
            if (info != null)
                newPlayer.method_48105(info.level, info.pos.field_1352, info.pos.field_1351, info.pos.field_1350,
                    Set.of(), newPlayer.method_36454(), newPlayer.method_36455(), false);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) ->
            mod.getPlayerDataManager().saveAll());
    }
}

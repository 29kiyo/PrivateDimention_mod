package dev.keiragi.privatedimension.fabric;

import dev.keiragi.privatedimension.CommonEventHandler;
import dev.keiragi.privatedimension.PrivateDimensionMod;
import dev.keiragi.privatedimension.item.DimensionBottleItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import dev.keiragi.privatedimension.registry.ModItems;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1269;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import java.nio.file.Path;
import java.util.*;

public class PrivateDimensionFabric implements ModInitializer {

    private PrivateDimensionMod mod;
    private CommonEventHandler eventHandler;
    private final Map<UUID, class_243> lastPos = new HashMap<>();
    private final Map<UUID, Boolean> cooldownActive = new HashMap<>();

    @Override
    public void onInitialize() {
        System.out.println("[PD] onInitialize開始");
        try {
            PrivateDimensionMod.LOGGER.info("アイテム登録開始");
            class_2960 id = class_2960.method_60655("privatedimension", "dimension_bottle");
            class_5321<class_1792> key = class_5321.method_29179(class_7923.field_41178.method_46765(), id);
            DimensionBottleItem item = new DimensionBottleItem(
                new class_1792.class_1793().method_63686(key).method_7889(1)
            );
            class_2378.method_39197(class_7923.field_41178, key, item);
            ModItems.DIMENSION_BOTTLE = item;
            PrivateDimensionMod.LOGGER.info("アイテム登録完了: {}", ModItems.DIMENSION_BOTTLE);
        } catch (Exception e) {
            PrivateDimensionMod.LOGGER.error("アイテム登録失敗: {}", e.getMessage(), e);
        }

        mod = new PrivateDimensionMod();
        mod.init();

        Path configDir = FabricLoader.getInstance().getConfigDir().resolve(PrivateDimensionMod.MOD_ID);
        mod.getConfig().setConfigPath(configDir.resolve("config.json"));
        mod.getConfig().load();

        mod.getPlayerDataManager().setDataPath(
            FabricLoader.getInstance().getGameDir()
                .resolve("world")
                .resolve("privatedimension_playerdata.json"));

        eventHandler = new CommonEventHandler(mod);

        registerEvents();
        FabricCommandHandler.register(mod, eventHandler);

        PrivateDimensionMod.LOGGER.info("PrivateDimension (Fabric) 初期化完了");
    }

    private void registerEvents() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            mod.getDimensionManager().onServerStart(server);
            mod.getPlayerDataManager().setDataPath(
                server.method_27050(net.minecraft.class_5218.field_24188)
                    .resolve("privatedimension_playerdata.json"));
        });

        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            mod.getPlayerDataManager().saveAll();
        });

        UseItemCallback.EVENT.register((player, world, hand) -> {
            PrivateDimensionMod.LOGGER.info("ItemEvents.USE fired: isClientSide={}", world.method_8608());
            if (world.method_8608() || !(player instanceof class_3222 sp)) {
                return class_1269.field_5811;
            }
            class_1799 stack = player.method_5998(hand);
            if (stack.method_7909() instanceof DimensionBottleItem) {
                eventHandler.onItemUse(sp, stack);
                return class_1269.field_5812;
            }
            return class_1269.field_5811;
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (class_3222 player : server.method_3760().method_14571()) {
                UUID uid = player.method_5667();
                class_243 current = player.method_73189();
                class_243 prev = lastPos.get(uid);
                if (prev == null || !prev.equals(current)) {
                    eventHandler.onPlayerMove(player, current);
                    lastPos.put(uid, current);
                }

                class_1799 mainHand = player.method_6047();
                if (DimensionBottleItem.isDimensionBottle(mainHand)) {
                    float cd = player.method_7357().method_7905(mainHand, 0f);
                    Boolean hadCooldown = cooldownActive.get(uid);
                    boolean hasCooldown = cd > 0f;
                    if (hadCooldown != null && !hadCooldown && hasCooldown) {
                        PrivateDimensionMod.LOGGER.info("Bottle cooldown detected for {}", player.method_5477().getString());
                        eventHandler.onItemUse(player, mainHand);
                    }
                    cooldownActive.put(uid, hasCooldown);
                }
            }
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof class_3222 sp) {
                eventHandler.onPlayerDeath(sp);
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            CommonEventHandler.RespawnInfo info = eventHandler.onPlayerRespawn(newPlayer);
            if (info != null) {
                newPlayer.method_48105(info.level, info.pos.field_1352, info.pos.field_1351, info.pos.field_1350,
                    java.util.Set.of(), newPlayer.method_36454(), newPlayer.method_36455(), true);
            }
        });

        net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents.DISCONNECT.register(
            (handler, server) -> mod.getPlayerDataManager().saveAll());
    }
}

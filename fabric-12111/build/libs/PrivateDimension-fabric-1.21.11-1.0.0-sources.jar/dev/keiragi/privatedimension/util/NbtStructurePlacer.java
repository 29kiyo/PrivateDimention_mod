package dev.keiragi.privatedimension.util;

import dev.keiragi.privatedimension.PrivateDimensionMod;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2505;
import net.minecraft.class_2507;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

/**
 * NBTファイルを直接パースしてブロックを配置するユーティリティ。
 * StructureTemplateManagerを使わないため全バージョンで動作する。
 */
public class NbtStructurePlacer {

    public static boolean place(class_3218 level, class_2338 origin, Path nbtPath) {
        try {
            if (!Files.exists(nbtPath)) {
                PrivateDimensionMod.LOGGER.error("NBTファイルが存在しません: {}", nbtPath);
                return false;
            }

            class_2487 root;
            try (InputStream is = Files.newInputStream(nbtPath)) {
                root = class_2507.method_10629(is, class_2505.method_53898());
            }

            // ブロックレジストリをlevel経由で取得（全バージョン共通）
            Object blockRegistry = level.method_30349()
                .method_30530(net.minecraft.class_7924.field_41254);

            class_2499 paletteTag = root.method_10554("palette").orElse(new class_2499());
            List<class_2680> palette = new ArrayList<>();
            for (int i = 0; i < paletteTag.size(); i++) {
                class_2487 entry = paletteTag.method_10602(i).orElse(new class_2487());
                String name = entry.method_10558("Name").orElse("");
                if (name.isEmpty()) {
                    palette.add(class_2246.field_10124.method_9564());
                    continue;
                }
                try {
                    int colon = name.indexOf(':');
                    String namespace = colon >= 0 ? name.substring(0, colon) : "minecraft";
                    String path     = colon >= 0 ? name.substring(colon + 1) : name;
                    // IdUtils経由でIdentifier/ResourceLocationを吸収
                    Object block = IdUtils.registryGetValue(blockRegistry, namespace, path);
                    if (!(block instanceof class_2248) || (block == class_2246.field_10124 && !name.contains("air"))) {
                        palette.add(class_2246.field_10124.method_9564());
                    } else {
                        class_2680 state = ((class_2248) block).method_9564();
                        if (entry.method_10545("Properties")) {
                            class_2487 props = entry.method_10562("Properties").orElse(new class_2487());
                            for (String key : props.method_10541()) {
                                String val = props.method_10558(key).orElse("");
                                if (!val.isEmpty()) {
                                    state = applyProperty(state, key, val);
                                }
                            }
                        }
                        palette.add(state);
                    }
                } catch (Exception e) {
                    PrivateDimensionMod.LOGGER.warn("ブロック解析失敗: {} -> {}", name, e.getMessage());
                    palette.add(class_2246.field_10124.method_9564());
                }
            }

            class_2499 blocks = root.method_10554("blocks").orElse(new class_2499());
            int placed = 0;
            for (int i = 0; i < blocks.size(); i++) {
                class_2487 blockEntry = blocks.method_10602(i).orElse(new class_2487());
                int stateIdx = blockEntry.method_10550("state").orElse(0);
                class_2499 posTag = blockEntry.method_10554("pos").orElse(new class_2499());
                int x = posTag.method_10600(0).orElse(0);
                int y = posTag.method_10600(1).orElse(0);
                int z = posTag.method_10600(2).orElse(0);

                if (stateIdx < 0 || stateIdx >= palette.size()) continue;
                class_2680 state = palette.get(stateIdx);

                class_2338 target = origin.method_10069(x, y, z);
                level.method_8652(target, state, class_2248.field_31036);
                placed++;
            }

            PrivateDimensionMod.LOGGER.info("NbtStructurePlacer: {}ブロック配置完了 at {}", placed, origin);
            return placed > 0;

        } catch (Exception e) {
            PrivateDimensionMod.LOGGER.error("NbtStructurePlacer失敗: {}", e.getMessage(), e);
            return false;
        }
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static class_2680 applyProperty(class_2680 state, String key, String value) {
        try {
            for (net.minecraft.class_2769<?> prop :
                    state.method_28501()) {
                if (prop.method_11899().equals(key)) {
                    java.util.Optional<?> parsed = prop.method_11900(value);
                    if (parsed.isPresent()) {
                        state = state.method_11657(
                                (net.minecraft.class_2769) prop,
                                (Comparable) parsed.get());
                    }
                    break;
                }
            }
        } catch (Exception ignored) {}
        return state;
    }
}

package dev.keiragi.privatedimension.util;

import dev.keiragi.privatedimension.PrivateDimensionMod;
import dev.keiragi.privatedimension.manager.PlayerDataManager;
import java.util.*;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5743;

public class TeleportHandler {
    private final PrivateDimensionMod mod;
    private final Set<UUID> teleporting = Collections.synchronizedSet(new HashSet<>());

    public TeleportHandler(PrivateDimensionMod mod) { this.mod = mod; }
    public boolean isTeleporting(UUID uid) { return teleporting.contains(uid); }

    public void handleUse(class_3222 player) {
        if (!teleporting.add(player.method_5667())) return;
        class_3218 pd = mod.getDimensionManager().getPrivateDimension();
        if (pd == null) {
            release(player.method_5667());
            player.method_64398(net.minecraft.class_2561.method_43470(
                "§c[PrivateDimension] 次元ワールドが準備できていません。"));
            return;
        }
        try {
            if (mod.getDimensionManager().isPrivateDimension((class_3218) player.method_51469()))
                gotoBaseWorld(player);
            else
                gotoPrivate(player, collectBringEntities(player));
        } catch (Exception e) {
            release(player.method_5667());
            PrivateDimensionMod.LOGGER.error("handleUse 例外: {}", e.getMessage());
        }
    }

    private void gotoPrivate(class_3222 player, List<class_1297> bring) {
        PlayerDataManager pdm = mod.getPlayerDataManager();
        UUID uid = player.method_5667();
        pdm.setReturnLocation(uid, (class_3218) player.method_51469(), player.method_73189(), player.method_36454(), player.method_36455());
        playVfx((class_3218) player.method_51469(), player.method_73189());
        addBlindness(player);
        if (pdm.hasPlot(uid)) gotoMyPlot(player, bring);
        else                   claimPlot(player, bring);
    }

    private void gotoMyPlot(class_3222 player, List<class_1297> bring) {
        PlayerDataManager pdm = mod.getPlayerDataManager();
        UUID uid = player.method_5667();
        class_3218 pd = mod.getDimensionManager().getPrivateDimension();
        int plotId = pdm.getPlotId(uid);
        class_2338 structOrigin = mod.getPlotManager().getPlotStructureOrigin(plotId);
        pd.method_22350(structOrigin);
        boolean needsStructure = pd.method_22347(structOrigin.method_10086(5));
        if (needsStructure) {
            PrivateDimensionMod.LOGGER.warn("プロット{}の構造物が見つかりません。再配置します。", plotId);
            pd.method_22350(class_2338.method_49638(mod.getPlotManager().getPlotSpawn(plotId)));
            mod.getDimensionManager().placeStructure(pd, structOrigin);
        }
        double[] saved = pdm.getPlotPos(uid);
        class_243 dest = saved != null ? new class_243(saved[0], saved[1], saved[2]) : mod.getPlotManager().getPlotSpawn(plotId);
        teleportTo(player, pd, dest);
        pullEntities(pd, dest, bring);
        playVfx(pd, dest);
        release(uid);
    }

    private void claimPlot(class_3222 player, List<class_1297> bring) {
        PlayerDataManager pdm = mod.getPlayerDataManager();
        UUID uid = player.method_5667();
        int plotId = pdm.getNextPlotId();
        pdm.setPlotId(uid, plotId);
        class_3218 pd = mod.getDimensionManager().getPrivateDimension();
        class_2338 origin = mod.getPlotManager().getPlotStructureOrigin(plotId);
        class_243 spawn = mod.getPlotManager().getPlotSpawn(plotId);
        pd.method_22350(class_2338.method_49638(spawn));
        pd.method_22350(origin);
        mod.getDimensionManager().placeStructure(pd, origin);
        addSlowFalling(player);
        teleportTo(player, pd, spawn);
        pdm.setPlotPosFromVec3(uid, spawn);
        pullEntities(pd, spawn, bring);
        playVfx(pd, spawn);
        release(uid);
    }

    public void gotoBaseWorld(class_3222 player) {
        UUID uid = player.method_5667();
        teleporting.add(uid);
        List<class_1297> bring = collectBringEntities(player);
        class_243 cur = player.method_73189();
        mod.getPlayerDataManager().setPlotPos(uid, cur.field_1352, cur.field_1351, cur.field_1350);
        PlayerDataManager.ReturnPos rp = mod.getPlayerDataManager().getReturnLocation(uid);
        class_3218 dest = (rp != null) ? rp.resolveLevel(player.method_51469().method_8503()) : player.method_51469().method_8503().method_30002();
        class_243 destPos = (rp != null) ? rp.toVec3() : new class_243(0, 64, 0);
        playVfx((class_3218) player.method_51469(), cur);
        addBlindness(player);
        teleportTo(player, dest, destPos);
        pullEntities(dest, destPos, bring);
        mod.getPlayerDataManager().clearReturnLocation(uid);
        playVfx(dest, destPos);
        release(uid);
    }

    private void teleportTo(class_3222 p, class_3218 level, class_243 pos) {
        p.method_48105(level, pos.field_1352, pos.field_1351, pos.field_1350, Set.of(), p.method_36454(), p.method_36455(), false);
    }

    private List<class_1297> collectBringEntities(class_3222 player) {
        if (!player.method_5715()) return Collections.emptyList();
        double r = mod.getConfig().pullEntityRadius;
        int lim = mod.getConfig().pullEntityLimit;
        List<class_1297> res = new ArrayList<>();
        class_238 box = player.method_5829().method_1014(r);
        for (class_1297 e : ((class_3218) player.method_51469()).method_18467(class_1297.class, box)) {
            if (e instanceof class_1588 || e instanceof class_1657
             || e instanceof net.minecraft.class_1542
             || e instanceof net.minecraft.class_1531) continue;
            res.add(e);
            if (res.size() >= lim) break;
        }
        return res;
    }

    private void pullEntities(class_3218 dest, class_243 pos, List<class_1297> entities) {
        for (class_1297 e : entities) {
            if (e instanceof class_3222 sp)
                sp.method_48105(dest, pos.field_1352, pos.field_1351, pos.field_1350, Set.of(), sp.method_36454(), sp.method_36455(), false);
            else
                e.method_5859(pos.field_1352, pos.field_1351, pos.field_1350);
        }
    }

    private void addBlindness(class_3222 p) {
        p.method_6092(new class_1293(class_1294.field_5919, 40, 0, true, false));
    }

    private void addSlowFalling(class_3222 p) {
        p.method_6092(new class_1293(class_1294.field_5906, 20, 0, true, false));
    }

    public void playVfx(class_3218 level, class_243 pos) {
        class_243 c = pos.method_1031(0, 1, 0);
        level.method_65096(class_2398.field_28479, c.field_1352, c.field_1351, c.field_1350, 50, 0.2, 0.5, 0.2, 1.0);
        level.method_65096(
            new class_5743(0x0000B2FF, 0x0099FFFF, 1.0f),
            c.field_1352, c.field_1351, c.field_1350, 100, 0.2, 0.5, 0.2, 1.0);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_14879, class_3419.field_15248, 2f, 0.8f);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_38371, class_3419.field_15248, 2f, 0.8f);
        level.method_43128(null, pos.field_1352, pos.field_1351, pos.field_1350, class_3417.field_26942, class_3419.field_15245, 2f, 1.2f);
    }

    private void release(UUID uid) { teleporting.remove(uid); }
}

package dev.keiragi.privatedimension;

import dev.keiragi.privatedimension.item.DimensionBottleItem;
import dev.keiragi.privatedimension.manager.PlayerDataManager;
import dev.keiragi.privatedimension.util.TeleportHandler;
import java.util.*;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class CommonEventHandler {
    private final PrivateDimensionMod mod;
    private final TeleportHandler teleportHandler;
    private final Set<UUID> diedInDimension = Collections.synchronizedSet(new HashSet<>());
    private static final long BORDER_COOLDOWN_MS = 2000;
    private final Map<UUID, Long> borderCooldown = new HashMap<>();

    public CommonEventHandler(PrivateDimensionMod mod) {
        this.mod = mod;
        this.teleportHandler = new TeleportHandler(mod);
    }

    public TeleportHandler getTeleportHandler() { return teleportHandler; }

    public boolean onItemUse(class_3222 player, class_1799 stack) {
        if (!(stack.method_7909() instanceof DimensionBottleItem)) return false;
        teleportHandler.handleUse(player);
        return true;
    }

    public void onPlayerMove(class_3222 player, class_243 newPos) {
        if (!mod.getDimensionManager().isPrivateDimension((class_3218) player.method_51469())) return;
        if (player.method_7338()) return;
        UUID uid = player.method_5667();
        if (!mod.getPlayerDataManager().hasPlot(uid)) return;
        if (teleportHandler.isTeleporting(uid)) return;
        int plotId = mod.getPlayerDataManager().getPlotId(uid);
        if (mod.getPlotManager().isInsidePlot(plotId, newPos.field_1352, newPos.field_1351, newPos.field_1350)) return;
        if (!mod.getConfig().borderEnforcement) return;
        long now = System.currentTimeMillis();
        Long last = borderCooldown.get(uid);
        if (last != null && now - last < BORDER_COOLDOWN_MS) return;
        borderCooldown.put(uid, now);
        player.method_64398(class_2561.method_43470("§c" + mod.getConfig().msgBorderForced));
        teleportHandler.playVfx((class_3218) player.method_51469(), player.method_73189());
        teleportHandler.gotoBaseWorld(player);
    }

    public void onPlayerDeath(class_3222 player) {
        if (mod.getDimensionManager().isPrivateDimension((class_3218) player.method_51469()))
            diedInDimension.add(player.method_5667());
    }

    public RespawnInfo onPlayerRespawn(class_3222 player) {
        UUID uid = player.method_5667();
        if (!diedInDimension.remove(uid)) return null;
        PlayerDataManager pdm = mod.getPlayerDataManager();
        PlayerDataManager.ReturnPos rp = pdm.getReturnLocation(uid);
        class_3218 dest = rp != null ? rp.resolveLevel(player.method_51469().method_8503()) : player.method_51469().method_8503().method_30002();
        class_243 destPos = rp != null ? rp.toVec3() : new class_243(0, 64, 0);
        pdm.clearReturnLocation(uid);
        if (pdm.hasPlot(uid))
            pdm.setPlotPosFromVec3(uid, mod.getPlotManager().getPlotSpawn(pdm.getPlotId(uid)));
        return new RespawnInfo(dest, destPos);
    }

    public static class RespawnInfo {
        public final class_3218 level;
        public final class_243 pos;
        public RespawnInfo(class_3218 level, class_243 pos) { this.level = level; this.pos = pos; }
    }
}

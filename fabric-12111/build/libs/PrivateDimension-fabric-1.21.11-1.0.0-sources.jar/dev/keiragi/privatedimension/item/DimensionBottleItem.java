package dev.keiragi.privatedimension.item;

import dev.keiragi.privatedimension.PrivateDimensionMod;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;

public class DimensionBottleItem extends class_1792 {
    public static final String ITEM_ID = "dimension_bottle";

    public DimensionBottleItem(class_1793 properties) {
        super(properties);
    }

    public static boolean isDimensionBottle(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        return stack.method_7909() instanceof DimensionBottleItem;
    }

    public static class_1799 createItem() {
        return dev.keiragi.privatedimension.registry.ModItems.DIMENSION_BOTTLE != null
            ? new class_1799(dev.keiragi.privatedimension.registry.ModItems.DIMENSION_BOTTLE)
            : class_1799.field_8037;
    }

    @Override
    public class_1269 method_7836(class_1937 level, class_1657 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (player.method_7357().method_7904(stack)) {
            return class_1269.field_5814;
        }
        if (!level.method_8608() && player instanceof net.minecraft.class_3222 sp) {
            PrivateDimensionMod mod = PrivateDimensionMod.getInstance();
            if (mod != null) {
                mod.getTeleportHandler().handleUse(sp);
                int cooldownTicks = mod.getConfig().cooldownSeconds * 20;
                player.method_7357().method_62835(stack, cooldownTicks);
            }
        }
        return class_1269.field_5812;
    }
}

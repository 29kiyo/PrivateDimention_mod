package dev.keiragi.privatedimension.item;

import java.util.List;
import java.util.Optional;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_9279;
import net.minecraft.class_9290;
import net.minecraft.class_9334;

public class DimensionBottleItem {

    public static final String ITEM_ID = "dimension_in_a_bottle";
    public static final String NBT_KEY = "privatedimension_item_id";

    public static class_1799 createItem() {
        class_1799 stack = new class_1799(class_1802.field_8150);

        stack.method_57379(class_9334.field_49631,
            class_2561.method_43470("Dimension in a Bottle")
                .method_27696(class_2583.field_24360.method_36139(0x40BFFF).method_10978(false)));

        stack.method_57379(class_9334.field_49632, new class_9290(List.of(
            class_2561.method_43473(),
            class_2561.method_43470("使用すると、別世界の空間へと移動する。")
                .method_27696(class_2583.field_24360.method_36139(0xFFFFFF).method_10978(false)),
            class_2561.method_43470("次元内で再び使用すると、元の世界へ戻る。")
                .method_27696(class_2583.field_24360.method_36139(0xFFFFFF).method_10978(false)),
            class_2561.method_43473(),
            class_2561.method_43470("\"この小さな丸い瓶の中には、")
                .method_27696(class_2583.field_24360.method_36139(0xAAAAAA).method_10978(false)),
            class_2561.method_43470(" どういうわけか別の世界が詰まっている\"")
                .method_27696(class_2583.field_24360.method_36139(0xAAAAAA).method_10978(false))
        )));

        stack.method_57379(class_9334.field_49651,
            new class_1844(Optional.empty(), Optional.of(0x40BFFF), List.of(), Optional.empty()));

        stack.method_57379(class_9334.field_49641, true);

        class_2487 tag = new class_2487();
        tag.method_10582(NBT_KEY, ITEM_ID);
        stack.method_57379(class_9334.field_49628, class_9279.method_57456(tag));

        return stack;
    }

    public static boolean isDimensionBottle(class_1799 stack) {
        if (stack == null || stack.method_7960()) return false;
        if (!stack.method_31574(class_1802.field_8150)) return false;
        class_9279 cd = stack.method_58694(class_9334.field_49628);
        if (cd == null) return false;
        return ITEM_ID.equals(cd.method_57461().method_10558(NBT_KEY));
    }
}

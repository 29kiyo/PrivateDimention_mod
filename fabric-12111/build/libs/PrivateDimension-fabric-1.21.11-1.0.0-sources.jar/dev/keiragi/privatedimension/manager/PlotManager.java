package dev.keiragi.privatedimension.manager;

import dev.keiragi.privatedimension.PrivateDimensionMod;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public class PlotManager {
    private final PrivateDimensionMod mod;
    public PlotManager(PrivateDimensionMod mod) { this.mod = mod; }

    public int getPlotOriginZ(int plotId) {
        return plotId * mod.getConfig().plotSpacing;
    }

    public class_243 getPlotSpawn(int plotId) {
        return new class_243(0.5, mod.getConfig().plotFloorY + 5, getPlotOriginZ(plotId) + 0.5);
    }

    public class_2338 getPlotStructureOrigin(int plotId) {
        return new class_2338(-24, mod.getConfig().plotFloorY - 1, getPlotOriginZ(plotId) - 24);
    }

    public boolean isInsidePlot(int plotId, double x, double y, double z) {
        int oz = getPlotOriginZ(plotId);
        int fy = mod.getConfig().plotFloorY;
        return x >= -24 && x <= 24
            && z >= (oz - 24) && z <= (oz + 24)
            && y >= (fy - 1)  && y <= (fy + 46);
    }
}
